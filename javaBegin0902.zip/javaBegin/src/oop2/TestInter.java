package oop2;

public interface TestInter {
	int DATA = 10000;
	public void printData();
}
