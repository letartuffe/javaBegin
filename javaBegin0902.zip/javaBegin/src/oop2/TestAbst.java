package oop2;

public abstract class TestAbst {
	int data = 10000;
	public abstract void printData();
}
