package oop;

public class CountConsMain {

	public static void main(String[] args) {
		CountCons cc1 = new CountCons();
		CountCons cc2 = new CountCons();
		CountCons cc3 = new CountCons();
	}

}
