
public class SimpleFor {

	public static void main(String[] args) {
		for(int i=1 ; i<=5 ; i++){
			System.out.println(i + "��° ����");
		}
		
		System.out.println("==================");
		for(int i=0 ; i<=9 ; i++){
			System.out.println(i + " * " + i + " = " + (i*i));
		}
	}

}









