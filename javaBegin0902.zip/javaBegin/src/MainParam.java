
public class MainParam {

	public static void main(String[] args) {
		String test = args[0];
		System.out.println(test);
	}

}
